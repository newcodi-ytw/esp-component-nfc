var structphalTop__T4T__t =
[
    [ "pAlT4TDataParams", "d1/d6b/structphalTop__T4T__t.html#aa9e95372693c9a7ef009e6530b235267", null ],
    [ "aNdefFileID", "d1/d6b/structphalTop__T4T__t.html#a7ec07f3bf3706b4c5aa85d1eec4d4eea", null ],
    [ "bRa", "d1/d6b/structphalTop__T4T__t.html#a91598212a9f051e28dbbe16a0d8c0e7f", null ],
    [ "bWa", "d1/d6b/structphalTop__T4T__t.html#a06ebea5cd47b0c5a220271ff5c38d243", null ],
    [ "bCurrentSelectedFile", "d1/d6b/structphalTop__T4T__t.html#aabd7a4f7b638c173d520d5c9dfab89d6", null ],
    [ "wMLe", "d1/d6b/structphalTop__T4T__t.html#abb05ccfdd0b9082533804db7c6973d12", null ],
    [ "wMLc", "d1/d6b/structphalTop__T4T__t.html#ac3666b57768ff1c8473ad01f5bf781c2", null ],
    [ "wCCLEN", "d1/d6b/structphalTop__T4T__t.html#ae9346092dd490c9a5e5aba179cfcf7a0", null ],
    [ "dwMaxFileSize", "d1/d6b/structphalTop__T4T__t.html#a0d1fc4c693c91619f70e707043c17c2c", null ],
    [ "wAdditionalInfo", "d1/d6b/structphalTop__T4T__t.html#aafe9f95551ad3a3f1a0c4eca5236dd26", null ],
    [ "bWrappedMode", "d1/d6b/structphalTop__T4T__t.html#a63125d50318663e7945fdba6c6128238", null ],
    [ "aAid", "d1/d6b/structphalTop__T4T__t.html#a3c25046b72ca7eddef1b1e89e8b14f6d", null ],
    [ "pCmdBuf", "d1/d6b/structphalTop__T4T__t.html#af53b24244e4e8b27f14511be5ad0008b", null ],
    [ "bCmdCode", "d1/d6b/structphalTop__T4T__t.html#aad4036b314743cdcb0937a1f8db7d8e6", null ],
    [ "bShortLenApdu", "d1/d6b/structphalTop__T4T__t.html#a9600ceb6ac1f28696c933051b8db3522", null ]
];