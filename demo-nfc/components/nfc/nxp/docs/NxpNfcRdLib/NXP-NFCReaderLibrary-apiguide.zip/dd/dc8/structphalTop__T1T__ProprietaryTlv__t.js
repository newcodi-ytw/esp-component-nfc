var structphalTop__T1T__ProprietaryTlv__t =
[
    [ "wOffset", "dd/dc8/structphalTop__T1T__ProprietaryTlv__t.html#afdc6eb02e29d289dc9a3d89efcb583a1", null ],
    [ "wLength", "dd/dc8/structphalTop__T1T__ProprietaryTlv__t.html#ad0f484532ee112433fde41dfb57ebb5e", null ]
];