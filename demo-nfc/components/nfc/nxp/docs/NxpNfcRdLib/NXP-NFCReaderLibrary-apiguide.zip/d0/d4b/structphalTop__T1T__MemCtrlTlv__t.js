var structphalTop__T1T__MemCtrlTlv__t =
[
    [ "wOffset", "d0/d4b/structphalTop__T1T__MemCtrlTlv__t.html#ab2bf5a4f01d3297622c4effd378d8fa9", null ],
    [ "wByteAddr", "d0/d4b/structphalTop__T1T__MemCtrlTlv__t.html#a17d22cf6e49a4abb8ccc2bdb9add5351", null ],
    [ "bSizeInBytes", "d0/d4b/structphalTop__T1T__MemCtrlTlv__t.html#a07152ca7858dabb6bda66d6ca2bedca7", null ],
    [ "bBytesPerPage", "d0/d4b/structphalTop__T1T__MemCtrlTlv__t.html#aab7d7d5943c6bd27edc7ba7afaf8d53f", null ]
];