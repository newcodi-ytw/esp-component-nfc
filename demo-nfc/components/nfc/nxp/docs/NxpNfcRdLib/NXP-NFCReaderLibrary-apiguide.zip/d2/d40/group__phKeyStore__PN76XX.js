var group__phKeyStore__PN76XX =
[
    [ "Defines", "d9/da8/group__phKeyStore__PN76XX__Defines.html", "d9/da8/group__phKeyStore__PN76XX__Defines" ],
    [ "phKeyStore_PN76XX_KeyEntry_t", "d4/d16/structphKeyStore__PN76XX__KeyEntry__t.html", [
      [ "aKey", "d4/d16/structphKeyStore__PN76XX__KeyEntry__t.html#a9afdd65ec4bfa349cb707268ba7eda66", null ],
      [ "bKeyLen", "d4/d16/structphKeyStore__PN76XX__KeyEntry__t.html#ab269b4d66b37e98f662338cc6bf10ad5", null ],
      [ "wKeyType", "d4/d16/structphKeyStore__PN76XX__KeyEntry__t.html#a6b7c4e56703d1f48c37b2c381f45985f", null ],
      [ "bKeyIndex", "d4/d16/structphKeyStore__PN76XX__KeyEntry__t.html#ab000c640ea2269427444f88074c09ecc", null ]
    ] ],
    [ "phKeyStore_PN76XX_DataParams_t", "d4/d76/structphKeyStore__PN76XX__DataParams__t.html", [
      [ "wId", "d4/d76/structphKeyStore__PN76XX__DataParams__t.html#a2d68fde5b51237d0a31ca014b4ac0d96", null ],
      [ "pKeyEntries", "d4/d76/structphKeyStore__PN76XX__DataParams__t.html#a00e0876061d7d00857e173fe9399a24b", null ],
      [ "pCryptoSymDataParams", "d4/d76/structphKeyStore__PN76XX__DataParams__t.html#a79d5aa51a68a8ca1f6d618eb93ea087a", null ],
      [ "wNoOfKeyEntries", "d4/d76/structphKeyStore__PN76XX__DataParams__t.html#ab403599852f38964daeb02eeaf2ec104", null ]
    ] ],
    [ "PH_KEYSTORE_PN76XX_ID", "d2/d40/group__phKeyStore__PN76XX.html#gaf401fda1a6358ef306e4b3350f7d4fbe", null ],
    [ "phKeyStore_PN76XX_Init", "d2/d40/group__phKeyStore__PN76XX.html#ga70ec5b72bf487960c77826d1ac9d25bf", null ],
    [ "phKeyStore_PN76XX_DeInit", "d2/d40/group__phKeyStore__PN76XX.html#ga0f2f203cb21eb0234a0116c5da9b775f", null ]
];