var structphpalI18000p3m3__Sw__DataParams__t =
[
    [ "wId", "d2/dad/structphpalI18000p3m3__Sw__DataParams__t.html#aab9a6514acebfbadca27aa42be6e8545", null ],
    [ "pHalDataParams", "d2/dad/structphpalI18000p3m3__Sw__DataParams__t.html#a4e2516dfe49da0216f4c49ddf6eccd6b", null ],
    [ "bSession", "d2/dad/structphpalI18000p3m3__Sw__DataParams__t.html#ab23490bc70e7e376a0efcf481c106eb2", null ],
    [ "abStoredCRC", "d2/dad/structphpalI18000p3m3__Sw__DataParams__t.html#afe4d6e4c28e2583e54dc03bff527733f", null ],
    [ "bStoredCRCValid", "d2/dad/structphpalI18000p3m3__Sw__DataParams__t.html#a51ffdaf5e5fa126aae2163feaee640ec", null ]
];