var group__phKeyStore__Sym__Defines__Size =
[
    [ "PH_KEYSTORE_KEY_TYPE_MIFARE_SIZE", "dc/dff/group__phKeyStore__Sym__Defines__Size.html#ga4187b02c5a445e610b25053509197560", null ],
    [ "PH_KEYSTORE_KEY_TYPE_AES128_SIZE", "dc/dff/group__phKeyStore__Sym__Defines__Size.html#gae8bc2daa0525e6719d455d50e968ab78", null ],
    [ "PH_KEYSTORE_KEY_TYPE_AES192_SIZE", "dc/dff/group__phKeyStore__Sym__Defines__Size.html#gac3bf3f32b0221360a7d6aab65d34d4ea", null ],
    [ "PH_KEYSTORE_KEY_TYPE_AES256_SIZE", "dc/dff/group__phKeyStore__Sym__Defines__Size.html#ga15601be15864cf952bac412cf98d76ef", null ]
];