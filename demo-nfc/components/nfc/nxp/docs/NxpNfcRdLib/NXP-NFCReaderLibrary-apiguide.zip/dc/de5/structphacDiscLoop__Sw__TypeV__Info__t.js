var structphacDiscLoop__Sw__TypeV__Info__t =
[
    [ "bTotalTagsFound", "dc/de5/structphacDiscLoop__Sw__TypeV__Info__t.html#a344b7988956429d252698ad673f1ca5b", null ],
    [ "bFlag", "dc/de5/structphacDiscLoop__Sw__TypeV__Info__t.html#a99856e235b79f96a8ddce5ad31bdd7f5", null ],
    [ "bMode", "dc/de5/structphacDiscLoop__Sw__TypeV__Info__t.html#a3e7b6f255430699956af4d249399fc9b", null ],
    [ "bDsfid", "dc/de5/structphacDiscLoop__Sw__TypeV__Info__t.html#a06e6215be4f25e6db193a5b8dbc6a91b", null ],
    [ "aUid", "dc/de5/structphacDiscLoop__Sw__TypeV__Info__t.html#a015f13f99319749657790396fe3bdde1", null ]
];