var group__phalI18000p3m3__Sw =
[
    [ "phalI18000p3m3_Sw_DataParams_t", "d6/d09/structphalI18000p3m3__Sw__DataParams__t.html", [
      [ "wId", "d6/d09/structphalI18000p3m3__Sw__DataParams__t.html#a97ef4f9da9e92dd2dad082a1d63550f6", null ],
      [ "pPalI18000p3m3DataParams", "d6/d09/structphalI18000p3m3__Sw__DataParams__t.html#a680e8232281c5787db334c5c8b0c75a3", null ],
      [ "abHandle", "d6/d09/structphalI18000p3m3__Sw__DataParams__t.html#ab174047c6f42c1e70c4a2783499ba78e", null ],
      [ "bHandleValid", "d6/d09/structphalI18000p3m3__Sw__DataParams__t.html#a52be86fbae5e046e57ed36e42b04efc3", null ]
    ] ],
    [ "PHAL_I18000P3M3_SW_ID", "dc/dfe/group__phalI18000p3m3__Sw.html#gaf105eb0c91646ee5876a0da215dc5054", null ],
    [ "phalI18000p3m3_Sw_Init", "dc/dfe/group__phalI18000p3m3__Sw.html#ga7ec4968e40089ae7e00fa926bbc7b6a8", null ]
];