var structphKeyStore__Sw__DataParams__t =
[
    [ "wId", "dc/dd5/structphKeyStore__Sw__DataParams__t.html#a554bc54e45c95bc9878e4cdfb880e360", null ],
    [ "pKeyEntries", "dc/dd5/structphKeyStore__Sw__DataParams__t.html#adade95f9575be6889c4267e4a2de77ba", null ],
    [ "pKeyVersionPairs", "dc/dd5/structphKeyStore__Sw__DataParams__t.html#a3d5bff046d1488006ae6fdcee743094c", null ],
    [ "wNoOfKeyEntries", "dc/dd5/structphKeyStore__Sw__DataParams__t.html#ad4a476268167c012b632f4e3be97fc4f", null ],
    [ "wNoOfVersions", "dc/dd5/structphKeyStore__Sw__DataParams__t.html#ab19526525bc942ac72aa20d4a8d84324", null ],
    [ "pKUCEntries", "dc/dd5/structphKeyStore__Sw__DataParams__t.html#abb186d929acd6c9b29b51b5d5028c5a9", null ],
    [ "wNoOfKUCEntries", "dc/dd5/structphKeyStore__Sw__DataParams__t.html#ac2a547df9fd1ccf616181cbd1270eb82", null ]
];