var structphKeyStore__Rc663__DataParams__t =
[
    [ "wId", "dc/d2a/structphKeyStore__Rc663__DataParams__t.html#a2d688d4c651d467bf242c48f0a1640ce", null ],
    [ "pHalDataParams", "dc/d2a/structphKeyStore__Rc663__DataParams__t.html#a4d8edfe885f93ed95a818468bd3aa233", null ]
];