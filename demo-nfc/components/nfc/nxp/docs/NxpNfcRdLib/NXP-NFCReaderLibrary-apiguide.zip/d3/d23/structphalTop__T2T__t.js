var structphalTop__T2T__t =
[
    [ "pAlT2TDataParams", "d3/d23/structphalTop__T2T__t.html#ae02f53fc4a1d442422e2832f0822aa41", null ],
    [ "pMemCtrlTlv", "d3/d23/structphalTop__T2T__t.html#affc1cf130a1a4f2f4c164b788ef2fb58", null ],
    [ "pLockCtrlTlv", "d3/d23/structphalTop__T2T__t.html#add0495e9510798264abd4233eb95e8fa", null ],
    [ "bRwa", "d3/d23/structphalTop__T2T__t.html#ae1f7c592bc94fad34fc741397b2d3ee9", null ],
    [ "bTms", "d3/d23/structphalTop__T2T__t.html#a15be3399e0d591f6a42f278a834d9582", null ],
    [ "bTagMemoryType", "d3/d23/structphalTop__T2T__t.html#a7a8a74857fff4773b5250aceecee54dc", null ],
    [ "bLockTlvCount", "d3/d23/structphalTop__T2T__t.html#a61ae168d4b695b8f84751162b093bd0f", null ],
    [ "bMemoryTlvCount", "d3/d23/structphalTop__T2T__t.html#a700fe640358f8aafb08bee63717a2eb0", null ],
    [ "wNdefHeaderAddr", "d3/d23/structphalTop__T2T__t.html#a5de7dd838ba16373da444ef2634fec24", null ],
    [ "wNdefMsgAddr", "d3/d23/structphalTop__T2T__t.html#ac23daa62e744ddc8740218402e1e20db", null ],
    [ "sSector", "d3/d23/structphalTop__T2T__t.html#a58a40e2d710b5430feab415ed417d702", null ],
    [ "bData", "d3/d23/structphalTop__T2T__t.html#a774685f81d4bfe4d593e2b11ff6524a7", null ],
    [ "wStartBlockNum", "d3/d23/structphalTop__T2T__t.html#a22b2dc513eefd301577c3ddf1d347a31", null ],
    [ "bDataIndex", "d3/d23/structphalTop__T2T__t.html#a3d4b222834fb7833a7e703e332e5aede", null ],
    [ "bNdefHeaderBlock", "d3/d23/structphalTop__T2T__t.html#a236470822caacb91adc3a0aba87f36bc", null ]
];