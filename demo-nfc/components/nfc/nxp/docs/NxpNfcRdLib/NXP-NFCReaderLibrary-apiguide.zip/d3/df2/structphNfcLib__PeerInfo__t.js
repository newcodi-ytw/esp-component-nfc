var structphNfcLib__PeerInfo__t =
[
    [ "dwActivatedType", "d3/df2/structphNfcLib__PeerInfo__t.html#aca38fe2161e0224c1b3630312e12e73d", null ],
    [ "wAtqa", "d3/df2/structphNfcLib__PeerInfo__t.html#a8acda873cb6f0a4b153df0b1443391a6", null ],
    [ "bUidLength", "d3/df2/structphNfcLib__PeerInfo__t.html#a881c028de71fafe8030a17b7c47ffc01", null ],
    [ "aUid", "d3/df2/structphNfcLib__PeerInfo__t.html#a08c6dc25f3174fd0578dc7661dfb5705", null ],
    [ "bSak", "d3/df2/structphNfcLib__PeerInfo__t.html#a7ad60921f735b7ad6c5859503be396d5", null ],
    [ "bAtqbLength", "d3/df2/structphNfcLib__PeerInfo__t.html#abdb73347619a3acb69394193e8d9edd8", null ],
    [ "aPupi", "d3/df2/structphNfcLib__PeerInfo__t.html#a47de43fabe6d079b1b0ccc1a34a6c5e6", null ],
    [ "aApplicationData", "d3/df2/structphNfcLib__PeerInfo__t.html#ab2253908c133bb63a8de26a09070588a", null ],
    [ "bIsExtendedAtqb", "d3/df2/structphNfcLib__PeerInfo__t.html#a6eb79c43373d57695121f25ae7a8b076", null ],
    [ "aProtocolInfo", "d3/df2/structphNfcLib__PeerInfo__t.html#a3b8988016924592c6bdca7833272f5ef", null ],
    [ "pUii", "d3/df2/structphNfcLib__PeerInfo__t.html#a81b181f56ea87223ae7147461fc75d5b", null ],
    [ "wUiiLength", "d3/df2/structphNfcLib__PeerInfo__t.html#a7e457ae720921fa19ac871b1bf55ba4c", null ],
    [ "tIso14443_4", "d3/df2/structphNfcLib__PeerInfo__t.html#abac60afd72de0e084ec2fdb725da6113", null ],
    [ "tIso18092", "d3/df2/structphNfcLib__PeerInfo__t.html#acbda92ec72211208446585a7aa2acd80", null ]
];