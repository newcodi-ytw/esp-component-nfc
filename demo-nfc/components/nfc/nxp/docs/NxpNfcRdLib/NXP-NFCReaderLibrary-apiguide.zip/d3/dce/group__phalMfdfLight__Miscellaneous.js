var group__phalMfdfLight__Miscellaneous =
[
    [ "PHAL_MFDFLIGHT_ADDITIONAL_INFO", "d3/dce/group__phalMfdfLight__Miscellaneous.html#gafa4df5e477c87f64170adadf1b2c5bdd", null ],
    [ "PHAL_MFDFLIGHT_WRAPPED_MODE", "d3/dce/group__phalMfdfLight__Miscellaneous.html#ga2b51c8d2bcda9fac85dae3b405ff0e89", null ],
    [ "PHAL_MFDFLIGHT_SHORT_LENGTH_APDU", "d3/dce/group__phalMfdfLight__Miscellaneous.html#ga05f833ca2b1eca1b0045ac322d97cebd", null ],
    [ "phalMfdfLight_GetConfig", "d3/dce/group__phalMfdfLight__Miscellaneous.html#ga6672416e5476fcb0fd6c532f3a6f311c", null ],
    [ "phalMfdfLight_SetConfig", "d3/dce/group__phalMfdfLight__Miscellaneous.html#ga2bdaf5bf7483f1490cd2040cbe3a16f2", null ],
    [ "phalMfdfLight_ResetAuthentication", "d3/dce/group__phalMfdfLight__Miscellaneous.html#ga0f5f37ac4764f730eb4b3312e0a3ff51", null ],
    [ "phalMfdfLight_CalculateTMV", "d3/dce/group__phalMfdfLight__Miscellaneous.html#gac1cbdc2aadab2fc743b0e293476a7ced", null ],
    [ "phalMfdfLight_DecryptReaderID", "d3/dce/group__phalMfdfLight__Miscellaneous.html#ga4c3cf35b5484f29ee922d78b108a91dc", null ]
];