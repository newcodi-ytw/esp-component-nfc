var structphalTop__T2T__MemCtrlTlv__t =
[
    [ "wOffset", "d8/d71/structphalTop__T2T__MemCtrlTlv__t.html#add1dabbbaa90f102128743b63d3e9269", null ],
    [ "wByteAddr", "d8/d71/structphalTop__T2T__MemCtrlTlv__t.html#aa77e5ae9d85a62c71ce6e663e30398a4", null ],
    [ "bSizeInBytes", "d8/d71/structphalTop__T2T__MemCtrlTlv__t.html#a1b42d5ae4134a96218e90b8252fb3ed2", null ],
    [ "bBytesPerPage", "d8/d71/structphalTop__T2T__MemCtrlTlv__t.html#a476c059db5fa707ca41801b75989ac44", null ]
];