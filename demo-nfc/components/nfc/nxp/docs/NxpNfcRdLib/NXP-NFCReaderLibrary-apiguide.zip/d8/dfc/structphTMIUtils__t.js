var structphTMIUtils__t =
[
    [ "pTMIBuffer", "d8/dfc/structphTMIUtils__t.html#a876d0a1b84af676d2a381131f0dd9568", null ],
    [ "dwTMIBufLen", "d8/dfc/structphTMIUtils__t.html#afeeaecfbd5cbb68f43b2921a11256775", null ],
    [ "dwTMIbufIndex", "d8/dfc/structphTMIUtils__t.html#a0364c290f513bc12023f9fbd32128706", null ],
    [ "bTMIStatus", "d8/dfc/structphTMIUtils__t.html#a58a0ab3b4da0b22ae2785ab6f97fd61d", null ],
    [ "dwOffsetInTMI", "d8/dfc/structphTMIUtils__t.html#abfae17fcb2ad259609d4fd089ca16bd2", null ]
];