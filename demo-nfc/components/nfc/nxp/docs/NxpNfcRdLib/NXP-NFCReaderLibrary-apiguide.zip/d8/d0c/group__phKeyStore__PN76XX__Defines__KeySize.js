var group__phKeyStore__PN76XX__Defines__KeySize =
[
    [ "PH_KEYSTORE_MAX_KEY_SIZE", "d8/d0c/group__phKeyStore__PN76XX__Defines__KeySize.html#ga506be0a1e1286a574275aa678c2571f1", null ],
    [ "PH_KEYSTORE_MAX_KEY_SIZE", "d8/d0c/group__phKeyStore__PN76XX__Defines__KeySize.html#ga506be0a1e1286a574275aa678c2571f1", null ]
];