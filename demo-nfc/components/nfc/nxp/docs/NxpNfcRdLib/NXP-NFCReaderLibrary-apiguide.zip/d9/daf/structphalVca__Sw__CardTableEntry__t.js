var structphalVca__Sw__CardTableEntry__t =
[
    [ "wIidIndex", "d9/daf/structphalVca__Sw__CardTableEntry__t.html#ad753a77aae4b02f385f8d1c6fdd6fd3f", null ],
    [ "bValid", "d9/daf/structphalVca__Sw__CardTableEntry__t.html#ab604f241e3d36bb759efde5ef83eabb5", null ],
    [ "pCardData", "d9/daf/structphalVca__Sw__CardTableEntry__t.html#a45c410ff5fb1b946c11bd1fde449eb77", null ]
];