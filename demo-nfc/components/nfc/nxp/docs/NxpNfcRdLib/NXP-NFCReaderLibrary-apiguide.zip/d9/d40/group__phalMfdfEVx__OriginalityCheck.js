var group__phalMfdfEVx__OriginalityCheck =
[
    [ "phalMfdfEVx_ReadSign", "d9/d40/group__phalMfdfEVx__OriginalityCheck.html#gad26b12ea64ea10f9816f26fd69838b4b", null ]
];