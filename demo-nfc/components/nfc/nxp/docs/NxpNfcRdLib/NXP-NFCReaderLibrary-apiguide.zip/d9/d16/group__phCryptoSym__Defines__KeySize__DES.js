var group__phCryptoSym__Defines__KeySize__DES =
[
    [ "PH_CRYPTOSYM_DES_BLOCK_SIZE", "d9/d16/group__phCryptoSym__Defines__KeySize__DES.html#ga59a88a0d3bbfca9ce46fe7ebbffc2599", null ],
    [ "PH_CRYPTOSYM_DES_KEY_SIZE", "d9/d16/group__phCryptoSym__Defines__KeySize__DES.html#gad735ac80425c15f6ffd011348b091588", null ],
    [ "PH_CRYPTOSYM_2K3DES_KEY_SIZE", "d9/d16/group__phCryptoSym__Defines__KeySize__DES.html#ga0788d4b36694491af7b2aaee22a34da7", null ],
    [ "PH_CRYPTOSYM_3K3DES_KEY_SIZE", "d9/d16/group__phCryptoSym__Defines__KeySize__DES.html#gabbe980938d0c538d19ee223bf6238692", null ]
];