var group__phce =
[
    [ "NFC Forum Type 4A Card Emulation", "da/da7/group__phceT4T.html", "da/da7/group__phceT4T" ]
];