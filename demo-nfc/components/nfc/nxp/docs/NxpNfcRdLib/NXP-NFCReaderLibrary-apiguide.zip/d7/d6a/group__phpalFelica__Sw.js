var group__phpalFelica__Sw =
[
    [ "phpalFelica_Sw_DataParams_t", "dd/d4c/structphpalFelica__Sw__DataParams__t.html", [
      [ "wId", "dd/d4c/structphpalFelica__Sw__DataParams__t.html#acf7704cde33f8f9db10d01f4978827d4", null ],
      [ "pHalDataParams", "dd/d4c/structphpalFelica__Sw__DataParams__t.html#a443c3c592778c6007e24d4c02c9aae35", null ],
      [ "aIDmPMm", "dd/d4c/structphpalFelica__Sw__DataParams__t.html#a4284af69b1884fd07f36b2eae3fd130f", null ],
      [ "bIDmPMmValid", "dd/d4c/structphpalFelica__Sw__DataParams__t.html#a53fd11a624513d004e7b1338f48e15ae", null ],
      [ "bLength", "dd/d4c/structphpalFelica__Sw__DataParams__t.html#a4226e9848065e33a69fded68902bb880", null ],
      [ "bRequestCode", "dd/d4c/structphpalFelica__Sw__DataParams__t.html#a3e293cd74a21cde256aca531588b3603", null ],
      [ "bTotalFrames", "dd/d4c/structphpalFelica__Sw__DataParams__t.html#a3da88cccce943a4133fa746bda9f7c84", null ],
      [ "bPreambleLen", "dd/d4c/structphpalFelica__Sw__DataParams__t.html#a1bc0da0aca49eac19cad8e2cfc1e4de7", null ]
    ] ],
    [ "PHPAL_FELICA_SW_ID", "d7/d6a/group__phpalFelica__Sw.html#ga89b5a4121b2de17cf5842e47d5673ca9", null ],
    [ "phpalFelica_Sw_Init", "d7/d6a/group__phpalFelica__Sw.html#ga8abd0e7161f16c9ed626637912569511", null ]
];