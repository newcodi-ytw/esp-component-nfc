var group__phalMfNtag42xDna__FileManagement =
[
    [ "PHAL_MFNTAG42XDNA_FILE_OPTION_PLAIN", "d7/d10/group__phalMfNtag42xDna__FileManagement.html#ga9b1c9338eb477231adea4565e66d4da1", null ],
    [ "PHAL_MFNTAG42XDNA_FILE_OPTION_PLAIN_1", "d7/d10/group__phalMfNtag42xDna__FileManagement.html#gafa32fa420ccc032aba6fd438ddcea984", null ],
    [ "PHAL_MFNTAG42XDNA_FILE_OPTION_MACD", "d7/d10/group__phalMfNtag42xDna__FileManagement.html#ga42c5b76a3fa3f10cc5776cf005d77e74", null ],
    [ "PHAL_MFNTAG42XDNA_FILE_OPTION_ENC", "d7/d10/group__phalMfNtag42xDna__FileManagement.html#ga50c55993367d05425f4a83c6f6501d0a", null ],
    [ "PHAL_MFNTAG42XDNA_SDM_ENABLED", "d7/d10/group__phalMfNtag42xDna__FileManagement.html#ga3eebf7b3c0f423d68903cb1cebdaa8c3", null ],
    [ "PHAL_MFNTAG42XDNA_VCUID_PRESENT", "d7/d10/group__phalMfNtag42xDna__FileManagement.html#gae779487a95147de3e9c75bd3707167b7", null ],
    [ "PHAL_MFNTAG42XDNA_RDCTR_PRESENT", "d7/d10/group__phalMfNtag42xDna__FileManagement.html#ga1ed1da0eb27f4c2c84a282bbaaaa5779", null ],
    [ "PHAL_MFNTAG42XDNA_RDCTR_LIMIT_PRESENT", "d7/d10/group__phalMfNtag42xDna__FileManagement.html#gabc34a3dea34e186a6cf8acab9683abc6", null ],
    [ "PHAL_MFNTAG42XDNA_SDM_ENC_FILE_DATA_PRESENT", "d7/d10/group__phalMfNtag42xDna__FileManagement.html#gad85ae7aa55a1f1d604b1a1b5a5df5a12", null ],
    [ "PHAL_MFNTAG42XDNA_SDM_TT_STATUS_PRESENT", "d7/d10/group__phalMfNtag42xDna__FileManagement.html#gafe110de5e8ec22d9138af1fb28cf82c1", null ],
    [ "PHAL_MFNTAG42XDNA_SDM_ENCODING_MODE_ASCII", "d7/d10/group__phalMfNtag42xDna__FileManagement.html#ga2907613ac763dff1a7ed7af6901837d2", null ],
    [ "PHAL_MFNTAG42XDNA_SPECIFICS_ENABLED", "d7/d10/group__phalMfNtag42xDna__FileManagement.html#ga9a2c17f118fb379a8c0e60aa1e59860e", null ],
    [ "phalMfNtag42XDna_GetFileSettings", "d7/d10/group__phalMfNtag42xDna__FileManagement.html#gaf4234e6d492afc35b4cd4347fafcc2fa", null ],
    [ "phalMfNtag42XDna_GetFileCounters", "d7/d10/group__phalMfNtag42xDna__FileManagement.html#ga55fb06aca6b622355f096d42ab47440f", null ],
    [ "phalMfNtag42XDna_ChangeFileSettings", "d7/d10/group__phalMfNtag42xDna__FileManagement.html#gaf266b8b47716a123f58eb67bc1919a13", null ],
    [ "phalMfNtag42XDna_ChangeFileSettingsSDM", "d7/d10/group__phalMfNtag42xDna__FileManagement.html#ga67fc5becb27590bba091586afce51152", null ]
];