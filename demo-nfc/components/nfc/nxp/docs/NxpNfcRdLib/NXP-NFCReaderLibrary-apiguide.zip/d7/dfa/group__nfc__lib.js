var group__nfc__lib =
[
    [ "NFC NXP NFC Library Definitions", "d1/d90/group__nfc__lib__definitions.html", "d1/d90/group__nfc__lib__definitions" ],
    [ "NFC Library Configuration Tags", "da/d35/group__nfc__lib__config__tags.html", "da/d35/group__nfc__lib__config__tags" ],
    [ "NFC Library Functions", "dd/dbf/group__nfc__lib__api.html", "dd/dbf/group__nfc__lib__api" ]
];