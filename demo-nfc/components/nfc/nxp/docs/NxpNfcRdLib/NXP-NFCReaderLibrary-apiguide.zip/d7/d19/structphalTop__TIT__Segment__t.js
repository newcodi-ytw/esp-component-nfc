var structphalTop__TIT__Segment__t =
[
    [ "bAddress", "d7/d19/structphalTop__TIT__Segment__t.html#a7cba951eac901556752c286e5d63e566", null ],
    [ "pData", "d7/d19/structphalTop__TIT__Segment__t.html#ad3b0949ef39b29be3e70d4b5b5edd989", null ],
    [ "bLockReservedOtp", "d7/d19/structphalTop__TIT__Segment__t.html#a16bac46e14007b7ee036d6bed696f51b", null ]
];