var group__phCryptoSym__Defines__ConfigTypes =
[
    [ "PH_CRYPTOSYM_CONFIG_KEY_TYPE", "d7/d4b/group__phCryptoSym__Defines__ConfigTypes.html#ga8d031e7ed1500f38aa2aeb12f7b83a49", null ],
    [ "PH_CRYPTOSYM_CONFIG_KEY_SIZE", "d7/d4b/group__phCryptoSym__Defines__ConfigTypes.html#ga716c74f5d584c4c57089f3a9e630600e", null ],
    [ "PH_CRYPTOSYM_CONFIG_BLOCK_SIZE", "d7/d4b/group__phCryptoSym__Defines__ConfigTypes.html#gabc3f36a94ae95808689980e59a7afd9c", null ],
    [ "PH_CRYPTOSYM_CONFIG_KEEP_IV", "d7/d4b/group__phCryptoSym__Defines__ConfigTypes.html#ga388ef4a053ed8260b9ca037e05759122", null ],
    [ "PH_CRYPTOSYM_CONFIG_LRP", "d7/d4b/group__phCryptoSym__Defines__ConfigTypes.html#gad920cd8e34d966919c3780f493ba862b", null ],
    [ "PH_CRYPTOSYM_CONFIG_LRP_NUMKEYS_UPDATE", "d7/d4b/group__phCryptoSym__Defines__ConfigTypes.html#gafaa08e184271102e2e2b8b7d22cd6572", null ],
    [ "PH_CRYPTOSYM_CONFIG_ADDITIONAL_INFO", "d7/d4b/group__phCryptoSym__Defines__ConfigTypes.html#gae2809136acb7bd86c7282ad88686cff0", null ]
];