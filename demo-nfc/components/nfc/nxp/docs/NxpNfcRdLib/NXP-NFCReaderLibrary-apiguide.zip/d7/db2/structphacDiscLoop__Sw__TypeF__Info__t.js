var structphacDiscLoop__Sw__TypeF__Info__t =
[
    [ "bTotalTagsFound", "d7/db2/structphacDiscLoop__Sw__TypeF__Info__t.html#aed407b03d3a9a56a192bb1b296bde695", null ],
    [ "aSystemCode", "d7/db2/structphacDiscLoop__Sw__TypeF__Info__t.html#ae684a3ef117e30a88230eb359efc87a0", null ],
    [ "bTimeSlot", "d7/db2/structphacDiscLoop__Sw__TypeF__Info__t.html#a5acca2a894a89f82fe118e456f64b43b", null ],
    [ "aIDmPMm", "d7/db2/structphacDiscLoop__Sw__TypeF__Info__t.html#ac8b8d23e901834242d54a16733cc9a13", null ],
    [ "aRD", "d7/db2/structphacDiscLoop__Sw__TypeF__Info__t.html#aae847e34898bfff4b30f37494f1bf7dc", null ],
    [ "bBaud", "d7/db2/structphacDiscLoop__Sw__TypeF__Info__t.html#a8408912c4e2ab756560c5962a204ce14", null ],
    [ "bSleepAFState", "d7/db2/structphacDiscLoop__Sw__TypeF__Info__t.html#a73a25811cf0b96593d7ab266a0e60dca", null ],
    [ "bLength", "d7/db2/structphacDiscLoop__Sw__TypeF__Info__t.html#af3f70228e3f0fb45cef6f3773a06dd4b", null ],
    [ "bDid", "d7/db2/structphacDiscLoop__Sw__TypeF__Info__t.html#a5680454cd3a88b3bc3a3def41722bdff", null ],
    [ "bLri", "d7/db2/structphacDiscLoop__Sw__TypeF__Info__t.html#ab1c24f7f7ac05c7b678ff357c03bc645", null ],
    [ "bNadEnable", "d7/db2/structphacDiscLoop__Sw__TypeF__Info__t.html#acef6c62861c4ee7490ea71cee6373b49", null ],
    [ "bNad", "d7/db2/structphacDiscLoop__Sw__TypeF__Info__t.html#a46a9d073321bc9da9240a1a654c300ce", null ],
    [ "pGi", "d7/db2/structphacDiscLoop__Sw__TypeF__Info__t.html#abdae63ec7c0e1333591e888927651127", null ],
    [ "bGiLength", "d7/db2/structphacDiscLoop__Sw__TypeF__Info__t.html#af46f7e9284b78c0bbc0bbca1929a78a2", null ],
    [ "pAtrRes", "d7/db2/structphacDiscLoop__Sw__TypeF__Info__t.html#abb04f7555849d38938cc5903ce1f4479", null ],
    [ "bAtrResLength", "d7/db2/structphacDiscLoop__Sw__TypeF__Info__t.html#aeab50afe733189debbab4424f08c3c5b", null ],
    [ "sTypeF_P2P", "d7/db2/structphacDiscLoop__Sw__TypeF__Info__t.html#a15a318ff9bee0cbab733a7f89696ee22", null ]
];