var group__phalMfdfEVx__MemoryConfiguration =
[
    [ "phalMfdfEVx_FreeMem", "de/dae/group__phalMfdfEVx__MemoryConfiguration.html#ga79d182feb8c4a9313957271cd8f0ec5c", null ],
    [ "phalMfdfEVx_GetVersion", "de/dae/group__phalMfdfEVx__MemoryConfiguration.html#gaf1db788d339c8939eb392aceca403bb4", null ]
];