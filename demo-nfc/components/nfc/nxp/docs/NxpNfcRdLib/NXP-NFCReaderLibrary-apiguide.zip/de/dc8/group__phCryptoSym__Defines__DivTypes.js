var group__phCryptoSym__Defines__DivTypes =
[
    [ "PH_CRYPTOSYM_DIV_MODE_MASK", "de/dc8/group__phCryptoSym__Defines__DivTypes.html#ga37eebb60c49ff36563423ed0959fb6a0", null ],
    [ "PH_CRYPTOSYM_DIV_MODE_DESFIRE", "de/dc8/group__phCryptoSym__Defines__DivTypes.html#ga3e2df166334fcae85bf877af64b3ded7", null ],
    [ "PH_CRYPTOSYM_DIV_MODE_MIFARE_PLUS", "de/dc8/group__phCryptoSym__Defines__DivTypes.html#gaa5ffcd3973a0346949e8563bc0783d30", null ],
    [ "PH_CRYPTOSYM_DIV_MODE_MIFARE_ULTRALIGHT", "de/dc8/group__phCryptoSym__Defines__DivTypes.html#ga56463799f4d56b6c68cb3af7d405a92e", null ],
    [ "PH_CRYPTOSYM_DIV_OPTION_2K3DES_FULL", "de/dc8/group__phCryptoSym__Defines__DivTypes.html#gadca3ca3d0d31d864f2311800e0a631b9", null ],
    [ "PH_CRYPTOSYM_DIV_OPTION_2K3DES_HALF", "de/dc8/group__phCryptoSym__Defines__DivTypes.html#ga48aaa23b549df1fd136b0778c048ecf2", null ]
];