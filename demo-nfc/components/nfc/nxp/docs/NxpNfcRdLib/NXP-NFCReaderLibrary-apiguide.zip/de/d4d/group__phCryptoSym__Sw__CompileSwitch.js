var group__phCryptoSym__Sw__CompileSwitch =
[
    [ "PH_CRYPTOSYM_SW_DES", "de/d4d/group__phCryptoSym__Sw__CompileSwitch.html#ga95740a2d131aa189e885dae7e188c829", null ],
    [ "PH_CRYPTOSYM_SW_AES", "de/d4d/group__phCryptoSym__Sw__CompileSwitch.html#ga7b5e29a3a12579fbd966985b7cc1053c", null ],
    [ "PH_CRYPTOSYM_SW_ONLINE_KEYSCHEDULING", "de/d4d/group__phCryptoSym__Sw__CompileSwitch.html#ga478615ee866518a462db7f0540c20f9a", null ],
    [ "PH_CRYPTOSYM_SW_ONLINE_CMAC_SUBKEY_CALCULATION", "de/d4d/group__phCryptoSym__Sw__CompileSwitch.html#gac38ca1e495dd5dacbb02e3570270d16e", null ],
    [ "PH_CRYPTOSYM_SW_ROM_OPTIMIZATION", "de/d4d/group__phCryptoSym__Sw__CompileSwitch.html#gadc5ae29472014ad7db6449f80c099458", null ],
    [ "PH_CRYTOSYM_SW_FAST_RAM", "de/d4d/group__phCryptoSym__Sw__CompileSwitch.html#ga2a74f87465dab1ddd3bf1f1de0afe438", null ],
    [ "PH_CRYPTOSYM_SW_CONST_ROM", "de/d4d/group__phCryptoSym__Sw__CompileSwitch.html#gaf28254385bc6f63c1bfff5cb7ccf9927", null ],
    [ "PH_CRYPTOSYM_SW_MAX_BLOCK_SIZE", "de/d4d/group__phCryptoSym__Sw__CompileSwitch.html#gae98deb420c833d4359a583069923bd2c", null ]
];