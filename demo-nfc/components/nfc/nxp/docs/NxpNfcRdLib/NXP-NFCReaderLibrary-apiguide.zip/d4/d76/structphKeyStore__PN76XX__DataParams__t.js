var structphKeyStore__PN76XX__DataParams__t =
[
    [ "wId", "d4/d76/structphKeyStore__PN76XX__DataParams__t.html#a2d68fde5b51237d0a31ca014b4ac0d96", null ],
    [ "pKeyEntries", "d4/d76/structphKeyStore__PN76XX__DataParams__t.html#a00e0876061d7d00857e173fe9399a24b", null ],
    [ "pCryptoSymDataParams", "d4/d76/structphKeyStore__PN76XX__DataParams__t.html#a79d5aa51a68a8ca1f6d618eb93ea087a", null ],
    [ "wNoOfKeyEntries", "d4/d76/structphKeyStore__PN76XX__DataParams__t.html#ab403599852f38964daeb02eeaf2ec104", null ]
];