var structphKeyStore__PN76XX__KeyEntry__t =
[
    [ "aKey", "d4/d16/structphKeyStore__PN76XX__KeyEntry__t.html#a9afdd65ec4bfa349cb707268ba7eda66", null ],
    [ "bKeyLen", "d4/d16/structphKeyStore__PN76XX__KeyEntry__t.html#ab269b4d66b37e98f662338cc6bf10ad5", null ],
    [ "wKeyType", "d4/d16/structphKeyStore__PN76XX__KeyEntry__t.html#a6b7c4e56703d1f48c37b2c381f45985f", null ],
    [ "bKeyIndex", "d4/d16/structphKeyStore__PN76XX__KeyEntry__t.html#ab000c640ea2269427444f88074c09ecc", null ]
];