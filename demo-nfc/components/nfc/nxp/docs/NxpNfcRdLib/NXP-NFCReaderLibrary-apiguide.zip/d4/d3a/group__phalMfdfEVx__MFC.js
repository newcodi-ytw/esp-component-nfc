var group__phalMfdfEVx__MFC =
[
    [ "phalMfdfEVx_CreateMFCMapping", "d4/d3a/group__phalMfdfEVx__MFC.html#ga42ec6d4cfabe4067ec85bd392946da79", null ],
    [ "phalMfdfEVx_RestoreTransfer", "d4/d3a/group__phalMfdfEVx__MFC.html#gad41c6e4d6bbab85e8b7f98165588ffc6", null ]
];