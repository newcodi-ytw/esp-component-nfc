var structphhalHw__Pn5190__Version__t =
[
    [ "bHw_Version", "d4/d9b/structphhalHw__Pn5190__Version__t.html#a37b67f3bf47a0324b2dc12a4810ab2c3", null ],
    [ "bROM_Version", "d4/d9b/structphhalHw__Pn5190__Version__t.html#ad221aa528112576436ce2ca45ef68df4", null ],
    [ "wFW_Version", "d4/d9b/structphhalHw__Pn5190__Version__t.html#ab98193a502b2cee58fe2cbad063d3763", null ]
];