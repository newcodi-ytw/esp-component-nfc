var group__phalMfpEVx__Errors =
[
    [ "PICC ErrorCodes", "d4/d5d/group__phalMfpEVx__PICC__Errors.html", "d4/d5d/group__phalMfpEVx__PICC__Errors" ],
    [ "Custom ErrorCodes", "db/d86/group__phalMfpEVx__Cust__Errors.html", "db/d86/group__phalMfpEVx__Cust__Errors" ]
];