var structphpalSli15693__Sw__DataParams__t =
[
    [ "wId", "da/d82/structphpalSli15693__Sw__DataParams__t.html#ae2abb33bd934ee8d60f233a946936b1d", null ],
    [ "pHalDataParams", "da/d82/structphpalSli15693__Sw__DataParams__t.html#a45a59b1a3600142d2e52364d851ed219", null ],
    [ "wAdditionalInfo", "da/d82/structphpalSli15693__Sw__DataParams__t.html#a68d5be297e15d3b63363ef663b3c981f", null ],
    [ "bFlags", "da/d82/structphpalSli15693__Sw__DataParams__t.html#a071173cd32413a31d1474946d8299c5a", null ],
    [ "bResFlags", "da/d82/structphpalSli15693__Sw__DataParams__t.html#a6e19981f7938a9017ca45fd375be9f7a", null ],
    [ "pUid", "da/d82/structphpalSli15693__Sw__DataParams__t.html#a6e9004cabe3f3319c16815c654e21755", null ],
    [ "bUidBitLength", "da/d82/structphpalSli15693__Sw__DataParams__t.html#a5fad8a6d11229557a82e2f0cc121549e", null ],
    [ "bExplicitlyAddressed", "da/d82/structphpalSli15693__Sw__DataParams__t.html#a5b62cf5fd8eb47f71e9f033c19fd134f", null ],
    [ "bOpeMode", "da/d82/structphpalSli15693__Sw__DataParams__t.html#a16b7fad74d9529a374088222863a3961", null ],
    [ "bBuffering", "da/d82/structphpalSli15693__Sw__DataParams__t.html#a8d5a6a1b279cbd99e01fef0b6fd829e8", null ],
    [ "bMaxRetryCount", "da/d82/structphpalSli15693__Sw__DataParams__t.html#ab9a69300a8464a7ce0c57c567c357f81", null ],
    [ "bIcMfgCode", "da/d82/structphpalSli15693__Sw__DataParams__t.html#ac9bade6330d7dcc657e29ce2d2e911f1", null ]
];