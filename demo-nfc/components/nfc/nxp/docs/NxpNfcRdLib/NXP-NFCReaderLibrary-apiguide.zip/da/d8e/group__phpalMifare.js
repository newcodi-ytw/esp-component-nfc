var group__phpalMifare =
[
    [ "Component : Software", "da/d53/group__phpalMifare__Sw.html", "da/d53/group__phpalMifare__Sw" ],
    [ "PhpalMifare_Stub", "da/dc0/group__phpalMifare__Stub.html", null ],
    [ "PHPAL_MIFARE_KEYA", "da/d8e/group__phpalMifare.html#ga469c768f6a3cfd41adfe58bc3e1cb004", null ],
    [ "PHPAL_MIFARE_KEYB", "da/d8e/group__phpalMifare.html#ga2bbc2df7d59fd67d5654086458da61d2", null ],
    [ "PHPAL_MIFARE_KEY_LENGTH", "da/d8e/group__phpalMifare.html#ga67b67907e61e07c28505984a66b5855c", null ],
    [ "phpalMifare_ExchangeL3", "da/d8e/group__phpalMifare.html#ga5aa4dc89a9e9c363f1b9bc573f26cc4b", null ],
    [ "phpalMifare_ExchangeL4", "da/d8e/group__phpalMifare.html#ga59416929edffcb86a8598c5ef15f4073", null ],
    [ "phpalMifare_ExchangePc", "da/d8e/group__phpalMifare.html#ga78bdc4c1968eae3124c1bda32be9bb64", null ],
    [ "phpalMifare_ExchangeRaw", "da/d8e/group__phpalMifare.html#ga5ff1aa7132f320af4edf65bf2bacc63f", null ],
    [ "phpalMifare_MfcAuthenticateKeyNo", "da/d8e/group__phpalMifare.html#ga59b3674a7707a1326c1857ec2acf9fd6", null ],
    [ "phpalMifare_MfcAuthenticate", "da/d8e/group__phpalMifare.html#ga420e47b3a8aacf09f9c30ca6167ce656", null ],
    [ "phpalMifare_SetMinFdtPc", "da/d8e/group__phpalMifare.html#ga2a05a2ec33ae036b25ce137187173d77", null ],
    [ "phpalMifare_GetConfig", "da/d8e/group__phpalMifare.html#ga6a42acae6543adb90b0601c725eaf909", null ]
];