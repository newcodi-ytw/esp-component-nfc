var structphalTop__T5T__t =
[
    [ "pAlI15693DataParams", "da/dec/structphalTop__T5T__t.html#a92f532872675980fbf48657780318224", null ],
    [ "bRwa", "da/dec/structphalTop__T5T__t.html#aa4d887147dd1134e38c437107b38b190", null ],
    [ "bTerminatorTlvPresence", "da/dec/structphalTop__T5T__t.html#aca70e25407302090f72a423fc1ebb126", null ],
    [ "bMbRead", "da/dec/structphalTop__T5T__t.html#a1460e1d74c00bf6412deedf2a987fca0", null ],
    [ "bLockBlock", "da/dec/structphalTop__T5T__t.html#a2a8578a5d857db47ac533cd7dece715b", null ],
    [ "bSplFrm", "da/dec/structphalTop__T5T__t.html#aa7b2ce069ced5b5234370a6237724dbc", null ],
    [ "bExtCmdSupt", "da/dec/structphalTop__T5T__t.html#a2e35b3b01f079ff746457540444b6590", null ],
    [ "bOptionFlag", "da/dec/structphalTop__T5T__t.html#a7bdfc4578018f3de74d304a8da04e1a5", null ],
    [ "wMlen", "da/dec/structphalTop__T5T__t.html#a02a1c82a311f0b8e72e0cc0c3f06f30f", null ],
    [ "wNdefHeaderAddr", "da/dec/structphalTop__T5T__t.html#a4ffad20ab0fd67093576f0f520e60cfa", null ],
    [ "wNdefMsgAddr", "da/dec/structphalTop__T5T__t.html#a9ff455eb842b3f6ec4891c6555b885df", null ],
    [ "bBlockSize", "da/dec/structphalTop__T5T__t.html#a875a8fbaf9874540f83e9a6045547912", null ],
    [ "bMaxBlockNum", "da/dec/structphalTop__T5T__t.html#aa6e71bbe1c3f806590083b1653448b23", null ],
    [ "bCcLength", "da/dec/structphalTop__T5T__t.html#a1aef7b56bb8d5471547052d15c1d3ed3", null ],
    [ "bCcBlockData", "da/dec/structphalTop__T5T__t.html#aec4e83f890168616414aebe36e3ee860", null ],
    [ "wStartBlockNum", "da/dec/structphalTop__T5T__t.html#a1974fdb68fff6c7ab735a2975b79b89a", null ],
    [ "wCcBlockDataLen", "da/dec/structphalTop__T5T__t.html#a7cef7880ac15d629030d80edeb737f35", null ],
    [ "wMaxReadLength", "da/dec/structphalTop__T5T__t.html#acd0941a8d8fe2e31cf2ba7a53fa8b5c0", null ]
];