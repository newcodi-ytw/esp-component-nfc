var structphacDiscLoop__I18000p3m3__Info__t =
[
    [ "bTotalTagsFound", "da/df4/structphacDiscLoop__I18000p3m3__Info__t.html#a24a554e2b00895ce64ad606bbb81c03b", null ],
    [ "bM", "da/df4/structphacDiscLoop__I18000p3m3__Info__t.html#ae4853e5c2c50615ea0ae8bdf714b706f", null ],
    [ "bDr", "da/df4/structphacDiscLoop__I18000p3m3__Info__t.html#a6f1d4ecfa5e1eced0483d9dc2ebf1e4e", null ],
    [ "aUii", "da/df4/structphacDiscLoop__I18000p3m3__Info__t.html#a6779fb6380c04abf8f018d464049d5af", null ],
    [ "wUiiLength", "da/df4/structphacDiscLoop__I18000p3m3__Info__t.html#afc5e7e67a0521ef8ee255acf40de4736", null ]
];