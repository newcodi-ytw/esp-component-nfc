var structphalTop__T2T__Sector__t =
[
    [ "bAddress", "d5/d3d/structphalTop__T2T__Sector__t.html#a16a46b3bd42b403c9cea76dd11a1c2ba", null ],
    [ "bBlockAddress", "d5/d3d/structphalTop__T2T__Sector__t.html#ab903a84d8e2a2d709ebec7b53e0ad3cb", null ],
    [ "bLockReservedOtp", "d5/d3d/structphalTop__T2T__Sector__t.html#a1337de8219ec87176e703e223b6eb623", null ],
    [ "bValidity", "d5/d3d/structphalTop__T2T__Sector__t.html#a54e2c3e2c7f105bde9b178d80083000d", null ]
];