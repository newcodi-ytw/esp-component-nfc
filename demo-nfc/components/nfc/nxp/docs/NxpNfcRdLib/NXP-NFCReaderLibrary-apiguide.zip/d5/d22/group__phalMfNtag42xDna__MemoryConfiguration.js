var group__phalMfNtag42xDna__MemoryConfiguration =
[
    [ "PHAL_MFNTAG42XDNA_SET_CONFIG_OPTION0", "d5/d22/group__phalMfNtag42xDna__MemoryConfiguration.html#gaf37dbf32ad5fb30a9c51b3b0dfbd51bb", null ],
    [ "PHAL_MFNTAG42XDNA_SET_CONFIG_OPTION4", "d5/d22/group__phalMfNtag42xDna__MemoryConfiguration.html#ga122b169cf5f58e0b01885503498fb8ab", null ],
    [ "PHAL_MFNTAG42XDNA_SET_CONFIG_OPTION5", "d5/d22/group__phalMfNtag42xDna__MemoryConfiguration.html#gacd39a39c0b10d22a9c8920f0919a16b7", null ],
    [ "PHAL_MFNTAG42XDNA_SET_CONFIG_OPTION7", "d5/d22/group__phalMfNtag42xDna__MemoryConfiguration.html#ga4d119eadd7979c82dcdaa92fef9b5db9", null ],
    [ "PHAL_MFNTAG42XDNA_SET_CONFIG_OPTION10", "d5/d22/group__phalMfNtag42xDna__MemoryConfiguration.html#ga4b2feb64036e52f140dfa1cc149b14a0", null ],
    [ "PHAL_MFNTAG42XDNA_SET_CONFIG_OPTION11", "d5/d22/group__phalMfNtag42xDna__MemoryConfiguration.html#ga85534c947748cf7215987b6c57823dd8", null ],
    [ "phalMfNtag42XDna_SetConfiguration", "d5/d22/group__phalMfNtag42xDna__MemoryConfiguration.html#ga345de1bb345b12a3e6162d5e57b02b74", null ],
    [ "phalMfNtag42XDna_GetVersion", "d5/d22/group__phalMfNtag42xDna__MemoryConfiguration.html#ga3af83c02c1fafc95a1ac766a76fd470c", null ],
    [ "phalMfNtag42XDna_GetCardUID", "d5/d22/group__phalMfNtag42xDna__MemoryConfiguration.html#gacc8baec619703606b3ff50a35dd2df70", null ]
];