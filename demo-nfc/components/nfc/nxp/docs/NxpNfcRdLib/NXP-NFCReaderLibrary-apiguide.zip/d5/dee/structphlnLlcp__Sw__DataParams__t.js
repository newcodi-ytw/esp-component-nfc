var structphlnLlcp__Sw__DataParams__t =
[
    [ "wId", "d5/dee/structphlnLlcp__Sw__DataParams__t.html#a65bae6db5f1e2a0e36c868ff57693dc8", null ],
    [ "pPalI18092DataParams", "d5/dee/structphlnLlcp__Sw__DataParams__t.html#a00c233d5b83b5220f6eb7fd21d7543e7", null ],
    [ "sLocalLMParams", "d5/dee/structphlnLlcp__Sw__DataParams__t.html#a8f7899703dedac63baa4627080aa81d9", null ],
    [ "sRemoteLMParams", "d5/dee/structphlnLlcp__Sw__DataParams__t.html#a21607a63273d86d6b0c0700d7fd696b4", null ],
    [ "bAgreedVersion", "d5/dee/structphlnLlcp__Sw__DataParams__t.html#aa097492e39a018be1238e2ce72b94655", null ],
    [ "bCurrentClientCnt", "d5/dee/structphlnLlcp__Sw__DataParams__t.html#ae3e179782f68822ebe13483dbf929c25", null ],
    [ "bSdpClientSAP", "d5/dee/structphlnLlcp__Sw__DataParams__t.html#a7943d58d1416e09d1abe6ea76a2b3e16", null ],
    [ "bMacType", "d5/dee/structphlnLlcp__Sw__DataParams__t.html#aa5810bb86ebc29541c7e19c28e5633c4", null ],
    [ "LlcpEventObj", "d5/dee/structphlnLlcp__Sw__DataParams__t.html#ad4d673cf0807af9341130181d6224a1f", null ]
];