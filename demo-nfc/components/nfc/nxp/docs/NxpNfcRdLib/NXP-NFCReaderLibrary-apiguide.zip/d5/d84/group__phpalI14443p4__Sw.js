var group__phpalI14443p4__Sw =
[
    [ "phpalI14443p4_Sw_DataParams_t", "d1/d45/structphpalI14443p4__Sw__DataParams__t.html", [
      [ "wId", "d1/d45/structphpalI14443p4__Sw__DataParams__t.html#aefd0858bc08a0d89acfaf027c1542b9a", null ],
      [ "pHalDataParams", "d1/d45/structphpalI14443p4__Sw__DataParams__t.html#a878bc2314885438355bb3125f0b9adba", null ],
      [ "bStateNow", "d1/d45/structphpalI14443p4__Sw__DataParams__t.html#a400e622de883c548159c2cb095e5f67d", null ],
      [ "bCidEnabled", "d1/d45/structphpalI14443p4__Sw__DataParams__t.html#a2d48b77529c1f5a0ec54f21b43fc9915", null ],
      [ "bCid", "d1/d45/structphpalI14443p4__Sw__DataParams__t.html#a94c87c1ab19d5f9087d50338563b5c7c", null ],
      [ "bNadEnabled", "d1/d45/structphpalI14443p4__Sw__DataParams__t.html#a7ef154af86ec8b6a97759fd69668baee", null ],
      [ "bNad", "d1/d45/structphpalI14443p4__Sw__DataParams__t.html#ac30f65ccf77e2665ee6cb672dfb36c7a", null ],
      [ "bFwi", "d1/d45/structphpalI14443p4__Sw__DataParams__t.html#a2c40e1eec07006f88c04380f745f3da8", null ],
      [ "bFsdi", "d1/d45/structphpalI14443p4__Sw__DataParams__t.html#a23e39e8eba797b6b740390215d4ae2f6", null ],
      [ "bFsci", "d1/d45/structphpalI14443p4__Sw__DataParams__t.html#af9e57dd6db582883f98bb7fba8f6f9c7", null ],
      [ "bPcbBlockNum", "d1/d45/structphpalI14443p4__Sw__DataParams__t.html#af0ab287bef4b4a773714f1080b559ae8", null ],
      [ "bMaxRetryCount", "d1/d45/structphpalI14443p4__Sw__DataParams__t.html#ad97f396f73f5a545f0fb5e082f65641d", null ],
      [ "bOpeMode", "d1/d45/structphpalI14443p4__Sw__DataParams__t.html#aa8c849dcb7265688af423d3a669a3459", null ]
    ] ],
    [ "PHPAL_I14443P4_SW_ID", "d5/d84/group__phpalI14443p4__Sw.html#ga8f163717138aa6c27c37d046f2a2fbb7", null ],
    [ "phpalI14443p4_Sw_Init", "d5/d84/group__phpalI14443p4__Sw.html#ga7699f44843642de662b32715e1aef2c5", null ]
];