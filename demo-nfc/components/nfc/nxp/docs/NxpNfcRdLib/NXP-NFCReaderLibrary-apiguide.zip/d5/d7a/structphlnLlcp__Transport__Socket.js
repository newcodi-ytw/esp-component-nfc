var structphlnLlcp__Transport__Socket =
[
    [ "xSema", "d5/d7a/structphlnLlcp__Transport__Socket.html#ac37829873e84b35537324c180a08e192", null ],
    [ "xRxSema", "d5/d7a/structphlnLlcp__Transport__Socket.html#a5a633c23843ea5bb6bd4ac273eb584a5", null ],
    [ "sSeq", "d5/d7a/structphlnLlcp__Transport__Socket.html#a869ca32db231fd1a2e662472b921e1e9", null ],
    [ "pNext", "d5/d7a/structphlnLlcp__Transport__Socket.html#a3fd8bf52c7f2706b949d810d395e3d78", null ],
    [ "pUri", "d5/d7a/structphlnLlcp__Transport__Socket.html#a146c515e0a44b47d761ed73134bdb849", null ],
    [ "dwBufLen", "d5/d7a/structphlnLlcp__Transport__Socket.html#a636ad655b5e3717ff5962c2fec796293", null ],
    [ "pbRxBuffer", "d5/d7a/structphlnLlcp__Transport__Socket.html#a27995e49f9904be963e58bf82525f70d", null ],
    [ "dwLength", "d5/d7a/structphlnLlcp__Transport__Socket.html#a5002e5ec7aa4edcfbd80a2e934310d21", null ],
    [ "wRMiu", "d5/d7a/structphlnLlcp__Transport__Socket.html#aa28d9521d3410491b7262cd97a6c188d", null ],
    [ "fReady", "d5/d7a/structphlnLlcp__Transport__Socket.html#a5a4f00e3ae359c7a22440badc4d944db", null ],
    [ "eSocketType", "d5/d7a/structphlnLlcp__Transport__Socket.html#a861998d1316ce4460052224e8a56c035", null ],
    [ "wStatus", "d5/d7a/structphlnLlcp__Transport__Socket.html#ae49fda57bf8cffd9822a07bc96101a71", null ],
    [ "bLsap", "d5/d7a/structphlnLlcp__Transport__Socket.html#a054df3a9edd0042b6c1841f10331354e", null ],
    [ "bRsap", "d5/d7a/structphlnLlcp__Transport__Socket.html#ac364c97e54207745662dc5577320c326", null ],
    [ "bState", "d5/d7a/structphlnLlcp__Transport__Socket.html#a8b82bc396e70464c89434606614698c1", null ]
];