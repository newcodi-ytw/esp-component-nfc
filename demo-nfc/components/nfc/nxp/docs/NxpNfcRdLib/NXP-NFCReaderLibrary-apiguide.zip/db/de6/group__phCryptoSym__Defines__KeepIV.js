var group__phCryptoSym__Defines__KeepIV =
[
    [ "PH_CRYPTOSYM_VALUE_KEEP_IV_OFF", "db/de6/group__phCryptoSym__Defines__KeepIV.html#ga2a2f733807120f3c7623c19798b98975", null ],
    [ "PH_CRYPTOSYM_VALUE_KEEP_IV_ON", "db/de6/group__phCryptoSym__Defines__KeepIV.html#gadd003c69a74fdcfe163af87683fa1d67", null ]
];