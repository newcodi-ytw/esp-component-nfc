var group__phCryptoSym__Defines__KeySize =
[
    [ "DES", "d9/d16/group__phCryptoSym__Defines__KeySize__DES.html", "d9/d16/group__phCryptoSym__Defines__KeySize__DES" ],
    [ "AES", "d9/d2c/group__phCryptoSym__Defines__KeySize__AES.html", "d9/d2c/group__phCryptoSym__Defines__KeySize__AES" ]
];