var group__phpalI18092mPI__Sw =
[
    [ "phpalI18092mPI_Sw_DataParams_t", "db/dfb/structphpalI18092mPI__Sw__DataParams__t.html", [
      [ "wId", "db/dfb/structphpalI18092mPI__Sw__DataParams__t.html#a7fc4954cb09fb96a2e734c37b35ea01c", null ],
      [ "wLastTxLen", "db/dfb/structphpalI18092mPI__Sw__DataParams__t.html#a2461c1f71b3f525b600662908c4375a9", null ],
      [ "pHalDataParams", "db/dfb/structphpalI18092mPI__Sw__DataParams__t.html#aba9cfa6f728c2c231f0fefecca1d9733", null ],
      [ "bNfcIdValid", "db/dfb/structphpalI18092mPI__Sw__DataParams__t.html#aeb4ccd0fc5f626b0f3e2815981ab472f", null ],
      [ "aNfcid3i", "db/dfb/structphpalI18092mPI__Sw__DataParams__t.html#add327675c0611884fcc4f12db160ed0b", null ],
      [ "bStateNow", "db/dfb/structphpalI18092mPI__Sw__DataParams__t.html#ad0bc2f8b55cec88ed73dc89a1f025b1e", null ],
      [ "bDid", "db/dfb/structphpalI18092mPI__Sw__DataParams__t.html#a96707b7c709b9fe6e1b6c5f1268b391b", null ],
      [ "bNadEnabled", "db/dfb/structphpalI18092mPI__Sw__DataParams__t.html#a2c11d490124fe607567dfb967ca4aaba", null ],
      [ "bNad", "db/dfb/structphpalI18092mPI__Sw__DataParams__t.html#a0396bc8adc52a21cf6350a609665a97f", null ],
      [ "bWt", "db/dfb/structphpalI18092mPI__Sw__DataParams__t.html#aab004da3b0db1d23d9e460a629726c69", null ],
      [ "bFsl", "db/dfb/structphpalI18092mPI__Sw__DataParams__t.html#ae84f60ab6cb9ab2ed8238bddd3501769", null ],
      [ "bPni", "db/dfb/structphpalI18092mPI__Sw__DataParams__t.html#aa5a9609c8a04d031a4824207a07bc131", null ],
      [ "bDsi", "db/dfb/structphpalI18092mPI__Sw__DataParams__t.html#a6ae88fbe29933e6c738515aaa1120734", null ],
      [ "bDri", "db/dfb/structphpalI18092mPI__Sw__DataParams__t.html#ac7130b8378c8a13c22a2b29ff221ad3b", null ],
      [ "bLri", "db/dfb/structphpalI18092mPI__Sw__DataParams__t.html#a6ca36c7ea150436cd3cc096db9c36a1c", null ],
      [ "bLrt", "db/dfb/structphpalI18092mPI__Sw__DataParams__t.html#a060a2786e4aac2b2d071deda53d017e4", null ],
      [ "bMaxRetryCount", "db/dfb/structphpalI18092mPI__Sw__DataParams__t.html#a619247286c0bc552b3b478db17cd1810", null ],
      [ "bAtnDisabled", "db/dfb/structphpalI18092mPI__Sw__DataParams__t.html#afb40aef520dd702b070589ef3503124e", null ],
      [ "bActiveMode", "db/dfb/structphpalI18092mPI__Sw__DataParams__t.html#aab57916ff40f692ea044d5995f8db85f", null ],
      [ "bOpeMode", "db/dfb/structphpalI18092mPI__Sw__DataParams__t.html#a28524f6f6bfb862d7276ed743d603b35", null ],
      [ "bPropPSLMode", "db/dfb/structphpalI18092mPI__Sw__DataParams__t.html#a5c531c1b4a2cb187bc1dac87786e2b3d", null ]
    ] ],
    [ "PHPAL_I18092MPI_SW_ID", "db/d07/group__phpalI18092mPI__Sw.html#ga56c3e92d6769a6b6fb2b54154d0ce503", null ],
    [ "PHPAL_I18092MPI_NFCID3_LENGTH", "db/d07/group__phpalI18092mPI__Sw.html#ga66927cb61a59f9b6f5ab945fde7f9b20", null ],
    [ "phpalI18092mPI_Sw_Init", "db/d07/group__phpalI18092mPI__Sw.html#ga11f021b30f30d36cb450d533465918b5", null ]
];